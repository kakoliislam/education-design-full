let logiForm = document.querySelector('.login-form');
document.querySelector('#login-btn').onclick = () =>{
    logiForm.classList.toggle('active');
}